<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
/*
Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
*/

Route::get('users', 'UserController@index');
Route::get('user/{id}', 'UserController@show');
Route::post('user/signup', 'UserController@store');
Route::post('login', 'UserController@isUser');

Route::put('user/{id}', 'UserController@update');
Route::delete('user/{id}', 'UserController@delete');

Route::get('specialists', 'SpecialistController@index');
Route::get('specialist/{id}', 'SpecialistController@show');
Route::post('specialist', 'SpecialistController@store');
Route::put('specialist/{id}', 'SpecialistController@update');
Route::delete('specialist/{id}', 'SpecialistController@delete');

Route::get('projects', 'ProjectConroller@index');
Route::get('project/{id}', 'ProjectConroller@show');
Route::post('project', 'ProjectConroller@store');
Route::put('project/{id}', 'ProjectConroller@update');
Route::delete('project/{id}', 'ProjectConroller@delete');

Route::get('feedbacks', 'FeedBackController@index');
Route::get('feedback/{id}', 'FeedBackController@show');
Route::post('feedback', 'FeedBackController@store');
Route::put('feedback/{id}', 'FeedBackController@update');
Route::delete('feedback/{id}', 'FeedBackController@delete');
