<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    //
   //'address', 'location', 'specialist', 
    protected $fillable = [
      'boss', 'type', 'due_date', 'details' ,'status'
    ];
}
