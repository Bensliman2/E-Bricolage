<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeedBack extends Model
{
     protected $fillable = [
       'project', 'user','specialist', 'rating', 'description'
     ];
}
