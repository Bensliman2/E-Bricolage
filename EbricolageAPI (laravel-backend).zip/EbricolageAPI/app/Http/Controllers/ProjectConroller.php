<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Project;

class ProjectConroller extends Controller
{
    //
     public function index()
    {
    $project= Project::all();
    return  response()->json($project);
    }
 
    public function show($id)
    {
        return Project::find($id);
    }

    public function store(Request $request)
    {
        return Project::create($request->all());
    }

    public function update(Request $request, $id)
    {
        $project = Project::findOrFail($id);
        $project->update($request->all());
        return $project;
    }

    public function delete($id)
    {
        $project = Project::findOrFail($id);
        $user->delete();
        return 204;
    }
}
