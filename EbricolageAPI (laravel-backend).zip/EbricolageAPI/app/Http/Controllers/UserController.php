<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;

class UserController extends Controller
{
    //
    public function index()
    {
    $users= User::all();
     return   response()->json($users);
    }
 
    public function show($id)
    {
        return User::find($id);
    }

    public function store(Request $request)
    {
          $rep= User::create($request->all());
          return response()->json(
            [
           'status' => 'success' ,
           'user' => $rep
           ]       
       );
    }

    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);
        $user->update($request->all());
      
        return $user;
    }

    public function delete($id)
    {
        $user = User::findOrFail($id);
        $user->delete();
        return 204;
    }

    public function isUser(Request $request)
    {
        /*
        $user = User::findOrFail($request=>'email');
        if($user=>'password' == $request=>'password')
        {
            return $user;
        }
        */
        $user =  User::where([
            ['email', '=',  $request->input('email')],
            ['password', '=', $request->input('password')]
            ])->get();

       if ($user->first()) { 
        return  response()->json(
            [
           'status' => 'success' ,
           'user' => $user
           ]  , 201      
       );

       } else{
        return  response()->json(
            [
           'status' => 'failure' ,
           'user' => $user->first()
           ]       
       );
       }       
         
    }
}
