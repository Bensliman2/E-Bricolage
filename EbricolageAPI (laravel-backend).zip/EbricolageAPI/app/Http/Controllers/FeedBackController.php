<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\FeedBack;

class FeedBackController extends Controller
{
    //
     public function index()
    {
    $feedBack= FeedBack::all();
    return  response()->json($feedBack);
    }
 
    public function show($id)
    {
        return FeedBack::find($id);
    }

    public function store(Request $request)
    {
        return FeedBack::create($request->all());
    }

    public function update(Request $request, $id)
    {
        $feedBack = FeedBack::findOrFail($id);
        $feedBack->update($request->all());
        return $feedBack;
    }

    public function delete($id)
    {
        $feedBack = FeedBack::findOrFail($id);
        $feedBack->delete();
        return 204;
    }
}
