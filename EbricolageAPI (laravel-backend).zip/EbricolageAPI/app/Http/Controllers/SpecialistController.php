<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Specialist;

class SpecialistController extends Controller
{
    //
    //
    public function index()
    {
    $specialist= Specialist::all();
    return  response()->json($specialist);
    }
 
    public function show($id)
    {
        return Specialist::find($id);
    }

    public function store(Request $request)
    {
        return Specialist::create($request->all());
    }

    public function update(Request $request, $id)
    {
        $specialist = Specialist::findOrFail($id);
        $specialist->update($request->all());
        return $specialist;
    }

    public function delete($id)
    {
        $specialist = Specialist::findOrFail($id);
        $specialist->delete();
        return 204;
    }
}
