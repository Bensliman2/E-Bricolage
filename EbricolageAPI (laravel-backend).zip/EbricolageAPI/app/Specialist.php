<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Specialist extends Model
{
    //
     protected $fillable = [
         'first_name', 'last_name', 'sex', 'email', 'password', 'adress',
         'phone', 'speciality', 'location', 'rating', 'projects_num'
    ];


     protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
}
